import hashlib
import csv
import logging
import os
from collections import Counter, defaultdict
from io import StringIO
import secrets
from datetime import date, datetime, time, timedelta, timezone
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import delete, func, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.database import get_db
from app import models, schemas
from app.emailing import EmailDeliveryError, send_business_invitation, send_email_verification
from app.auth import ACCESS_TOKEN_TTL, create_access_token, create_refresh_token, decode_access_token, decode_refresh_token, get_business_membership, get_current_user, hash_password, unauthorized_token, verify_password

app = FastAPI(
    title="SmartBiz API",
    description="Sales management and business analytics for small businesses.",
    version="0.4.0",
)
logger = logging.getLogger(__name__)

web_origins = [
    origin.strip()
    for origin in os.getenv("WEB_ORIGINS", "http://localhost:3000,http://localhost:5000").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=web_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type", "X-Business-Id"],
)


def require_membership(
    x_business_id: int | None = Header(default=None),
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> models.BusinessMembership:
    return get_business_membership(x_business_id, current_user, db)


def require_business(membership: models.BusinessMembership = Depends(require_membership)) -> models.Business:
    return membership.business


def require_roles(*allowed: str):
    def check_role(membership: models.BusinessMembership = Depends(require_membership)) -> models.BusinessMembership:
        if membership.role not in allowed:
            raise HTTPException(status_code=403, detail="Your business role cannot perform this action")
        return membership
    return check_role


def auth_response(user: models.User, db: Session) -> dict:
    memberships = db.scalars(
        select(models.BusinessMembership)
        .options(selectinload(models.BusinessMembership.business))
        .where(models.BusinessMembership.user_id == user.id)
    ).all()
    return {
        "access_token": create_access_token(user.id),
        "refresh_token": create_refresh_token(user.id),
        "token_type": "bearer",
        "expires_in": int(ACCESS_TOKEN_TTL.total_seconds()),
        "user": user,
        "memberships": [{"business": membership.business, "role": membership.role} for membership in memberships],
    }


def enforce_auth_rate_limit(request: Request, db: Session, action: str, identity: str, limit: int) -> None:
    """Apply a shared PostgreSQL fixed-window limit to auth actions."""
    now = datetime.now(timezone.utc)
    window = now.replace(second=0, microsecond=0)
    client_ip = request.client.host if request.client else "unknown"
    if os.getenv("RATE_LIMIT_TRUST_PROXY", "false").strip().lower() == "true":
        forwarded_for = request.headers.get("cf-connecting-ip") or request.headers.get("x-forwarded-for", "")
        if forwarded_for.strip():
            client_ip = forwarded_for.split(",", 1)[0].strip()
    identities = {f"{action}:ip:{client_ip}", f"{action}:identity:{identity}"}
    for raw_key in identities:
        key = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()
        statement = pg_insert(models.RateLimitBucket).values(
            key=key, window_start=window, request_count=1,
        ).on_conflict_do_update(
            index_elements=[models.RateLimitBucket.key, models.RateLimitBucket.window_start],
            set_={"request_count": models.RateLimitBucket.request_count + 1},
        ).returning(models.RateLimitBucket.request_count)
        count = db.scalar(statement)
        if count > limit:
            db.commit()
            raise HTTPException(status_code=429, detail="Too many attempts. Please try again in a minute.", headers={"Retry-After": "60"})
    db.execute(delete(models.RateLimitBucket).where(models.RateLimitBucket.window_start < now - timedelta(minutes=5)))
    db.commit()


def create_verification(db: Session, user: models.User, pending_email: str | None = None) -> tuple[str, str]:
    token = secrets.token_urlsafe(32)
    db.execute(delete(models.EmailVerification).where(models.EmailVerification.user_id == user.id))
    db.add(models.EmailVerification(
        user_id=user.id,
        token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(),
        pending_email=pending_email,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=24),
    ))
    db.commit()
    return token, f"{os.getenv('APP_BASE_URL', 'http://localhost:3000').rstrip('/')}/#verify={token}"


def reporting_window(
    business: models.Business,
    from_date: date | None,
    to_date: date | None,
) -> tuple[datetime, datetime, date, date, ZoneInfo]:
    try:
        business_zone = ZoneInfo(business.timezone)
    except ZoneInfoNotFoundError:
        raise HTTPException(status_code=422, detail="Business timezone is not a valid IANA timezone") from None
    local_today = datetime.now(business_zone).date()
    end_day = to_date or local_today
    if end_day == date.max:
        raise HTTPException(status_code=422, detail="to_date is outside the supported range")
    try:
        start_day = from_date or end_day - timedelta(days=29)
    except OverflowError:
        raise HTTPException(status_code=422, detail="to_date is outside the supported range") from None
    if start_day > end_day:
        raise HTTPException(status_code=422, detail="from_date must be on or before to_date")
    if (end_day - start_day).days > 365:
        raise HTTPException(status_code=422, detail="Date range cannot exceed 366 calendar days")
    start_utc = datetime.combine(start_day, time.min, tzinfo=business_zone).astimezone(timezone.utc)
    end_utc = datetime.combine(end_day + timedelta(days=1), time.min, tzinfo=business_zone).astimezone(timezone.utc)
    return start_utc, end_utc, start_day, end_day, business_zone


def report_buckets(interval: str, start_day: date, end_day: date) -> list[date]:
    if interval == "day":
        return [start_day + timedelta(days=offset) for offset in range((end_day - start_day).days + 1)]
    if interval == "week":
        first = start_day - timedelta(days=start_day.weekday())
        buckets: list[date] = []
        current = first
        while current <= end_day:
            buckets.append(current)
            current += timedelta(days=7)
        return buckets
    current = start_day.replace(day=1)
    buckets = []
    while current <= end_day:
        buckets.append(current)
        if current.year == end_day.year and current.month == end_day.month:
            break
        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(current.year, current.month + 1, 1)
    return buckets


def csv_safe(value: object) -> str:
    result = str(value)
    if result.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + result
    return result


@app.get("/health", tags=["operations"])
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/ready", tags=["operations"])
def ready(db: Session = Depends(get_db)) -> dict[str, str]:
    db.execute(select(1))
    return {"status": "ready"}


@app.post("/api/v1/auth/register", response_model=schemas.RegistrationOut, status_code=201, tags=["authentication"])
def register(payload: schemas.RegisterRequest, request: Request, db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    enforce_auth_rate_limit(request, db, "register", email, 5)
    user = models.User(email=email, full_name=payload.full_name.strip(), password_hash=hash_password(payload.password), email_verified=False)
    if payload.business_name is not None:
        business = models.Business(name=payload.business_name.strip())
        user.memberships.append(models.BusinessMembership(business=business, role="owner"))
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account with this email already exists") from None
    db.refresh(user)
    token, verification_url = create_verification(db, user)
    try:
        email_sent = send_email_verification(recipient=user.email, token=token)
    except EmailDeliveryError as exc:
        logger.warning("Verification email delivery failed for user %s: %s", user.id, exc)
        delivery_status = "failed"
    else:
        delivery_status = "sent" if email_sent else "manual"
    return {
        "message": "Check your email to verify your account before signing in.",
        "delivery_status": delivery_status,
        "verification_url": verification_url if delivery_status != "sent" else None,
    }


@app.post("/api/v1/auth/login", response_model=schemas.AuthOut, tags=["authentication"])
def login(payload: schemas.LoginRequest, request: Request, db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    enforce_auth_rate_limit(request, db, "login", email, 10)
    user = db.scalar(select(models.User).where(models.User.email == email))
    if user is None or not user.active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password", headers={"WWW-Authenticate": "Bearer"})
    if not user.email_verified:
        token, verification_url = create_verification(db, user)
        try:
            email_sent = send_email_verification(recipient=user.email, token=token)
        except EmailDeliveryError:
            email_sent = False
        detail = {"message": "Verify your email before signing in.", "delivery_status": "sent" if email_sent else "manual", "verification_url": None if email_sent else verification_url}
        raise HTTPException(status_code=403, detail=detail)
    return auth_response(user, db)


@app.post("/api/v1/auth/refresh", response_model=schemas.AuthOut, tags=["authentication"])
def refresh_token(payload: schemas.RefreshTokenRequest, db: Session = Depends(get_db)):
    claims = decode_refresh_token(payload.refresh_token)
    user_id = int(claims["sub"])
    jti = claims["jti"]
    user = db.get(models.User, user_id)
    if user is None or not user.active or not user.email_verified:
        raise unauthorized_token("Account inactive or unverified")
    exp_timestamp = claims.get("exp")
    expires_at = datetime.fromtimestamp(exp_timestamp, tz=timezone.utc) if exp_timestamp else models.utc_now()
    consumed = db.scalar(
        pg_insert(models.TokenRevocation)
        .values(token_id=jti, user_id=user.id, expires_at=expires_at)
        .on_conflict_do_nothing(index_elements=[models.TokenRevocation.token_id])
        .returning(models.TokenRevocation.token_id)
    )
    if consumed is None:
        db.rollback()
        raise unauthorized_token("Refresh token has already been used")
    db.commit()
    return auth_response(user, db)


@app.post("/api/v1/auth/verify-email", status_code=204, tags=["authentication"])
def verify_email(payload: schemas.EmailVerificationRequest, request: Request, db: Session = Depends(get_db)):
    enforce_auth_rate_limit(request, db, "verify", "verification", 20)
    token_hash = hashlib.sha256(payload.token.encode("utf-8")).hexdigest()
    verification = db.scalar(select(models.EmailVerification).where(models.EmailVerification.token_hash == token_hash).with_for_update())
    if verification is None:
        raise HTTPException(status_code=404, detail="Verification link is invalid or already used")
    if verification.expires_at <= datetime.now(timezone.utc):
        db.delete(verification)
        db.commit()
        raise HTTPException(status_code=410, detail="Verification link has expired. Sign in to request a new one.")
    user = db.get(models.User, verification.user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="Account not found")
    if verification.pending_email is not None:
        duplicate = db.scalar(select(models.User.id).where(models.User.email == verification.pending_email, models.User.id != user.id))
        if duplicate is not None:
            raise HTTPException(status_code=409, detail="That email address is already linked to another account")
        user.email = verification.pending_email
    user.email_verified = True
    db.delete(verification)
    db.execute(delete(models.EmailVerification).where(models.EmailVerification.user_id == user.id))
    db.commit()
    return Response(status_code=204)


@app.patch("/api/v1/auth/profile", response_model=schemas.UserOut, tags=["authentication"])
def update_profile(payload: schemas.ProfileUpdate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    current_user.full_name = payload.full_name.strip()
    if not current_user.full_name:
        raise HTTPException(status_code=422, detail="Name cannot be blank")
    db.commit()
    db.refresh(current_user)
    return current_user


@app.post("/api/v1/auth/email-change", tags=["authentication"])
def request_email_change(payload: schemas.EmailChangeRequest, request: Request, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    email = payload.email.strip().lower()
    if not verify_password(payload.current_password, current_user.password_hash):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    if email == current_user.email:
        raise HTTPException(status_code=409, detail="This is already your account email")
    if db.scalar(select(models.User.id).where(models.User.email == email)) is not None:
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    enforce_auth_rate_limit(request, db, "email-change", email, 5)
    token, verification_url = create_verification(db, current_user, pending_email=email)
    try:
        email_sent = send_email_verification(recipient=email, token=token)
    except EmailDeliveryError as exc:
        logger.warning("Email change verification delivery failed for user %s: %s", current_user.id, exc)
        email_sent = False
    return {"message": "Confirm the new email address to finish changing it.", "delivery_status": "sent" if email_sent else "manual", "verification_url": None if email_sent else verification_url}


@app.post("/api/v1/auth/password", tags=["authentication"])
def change_password(payload: schemas.PasswordChangeRequest, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(payload.current_password, current_user.password_hash):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    if verify_password(payload.new_password, current_user.password_hash):
        raise HTTPException(status_code=422, detail="Choose a password different from your current one")
    current_user.password_hash = hash_password(payload.new_password)
    db.commit()
    return {"message": "Password changed successfully."}


@app.get("/api/v1/auth/me", response_model=schemas.AccountOut, tags=["authentication"])
def current_account(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    memberships = db.scalars(
        select(models.BusinessMembership)
        .options(selectinload(models.BusinessMembership.business))
        .where(models.BusinessMembership.user_id == current_user.id)
    ).all()
    return {"user": current_user, "memberships": [{"business": item.business, "role": item.role} for item in memberships]}


@app.post("/api/v1/auth/logout", tags=["authentication"])
def logout(
    request_body: schemas.LogoutRequest | None = None,
    payload: dict = Depends(decode_access_token),
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    now = datetime.now(timezone.utc)
    db.execute(delete(models.TokenRevocation).where(models.TokenRevocation.expires_at <= now))
    db.add(models.TokenRevocation(
        token_id=payload["jti"],
        user_id=current_user.id,
        expires_at=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
    ))
    if request_body and request_body.refresh_token:
        try:
            claims = decode_refresh_token(request_body.refresh_token)
        except HTTPException:
            claims = None
        if claims and int(claims["sub"]) == current_user.id:
            exp = datetime.fromtimestamp(claims["exp"], tz=timezone.utc)
            db.merge(models.TokenRevocation(token_id=claims["jti"], user_id=current_user.id, expires_at=exp))
    db.commit()
    return {"status": "logged_out"}


@app.post("/api/v1/businesses", response_model=schemas.BusinessOut, status_code=201, tags=["businesses"])
def create_business(payload: schemas.BusinessCreate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    business = models.Business(**payload.model_dump())
    db.add(business)
    db.flush()
    db.add(models.BusinessMembership(user_id=current_user.id, business_id=business.id, role="owner"))
    db.commit()
    db.refresh(business)
    return business


@app.get("/api/v1/businesses", response_model=list[schemas.MembershipOut], tags=["businesses"])
def list_businesses(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    memberships = db.scalars(
        select(models.BusinessMembership)
        .options(selectinload(models.BusinessMembership.business))
        .where(models.BusinessMembership.user_id == current_user.id)
    ).all()
    return [{"business": item.business, "role": item.role} for item in memberships]


@app.post("/api/v1/businesses/members", response_model=schemas.MemberOut, status_code=201, tags=["businesses"])
def add_business_member(
    payload: schemas.MemberCreate,
    membership: models.BusinessMembership = Depends(require_roles("owner", "admin")),
    db: Session = Depends(get_db),
):
    if payload.role == "admin" and membership.role != "owner":
        raise HTTPException(status_code=403, detail="Only the business owner can grant the admin role")
    user = db.scalar(select(models.User).where(models.User.email == payload.email.strip().lower()))
    if user is None:
        raise HTTPException(status_code=404, detail="Create the user's SmartBiz account before adding them")
    new_membership = models.BusinessMembership(business_id=membership.business_id, user_id=user.id, role=payload.role)
    db.add(new_membership)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="This user is already a member of the business") from None
    return {"user": user, "role": new_membership.role}


@app.get("/api/v1/businesses/members", response_model=list[schemas.MemberOut], tags=["businesses"])
def list_business_members(membership: models.BusinessMembership = Depends(require_membership), db: Session = Depends(get_db)):
    records = db.scalars(
        select(models.BusinessMembership)
        .options(selectinload(models.BusinessMembership.user))
        .where(models.BusinessMembership.business_id == membership.business_id)
        .order_by(models.BusinessMembership.id)
    ).all()
    return [{"user": item.user, "role": item.role} for item in records]


@app.delete("/api/v1/businesses/members/{user_id}", status_code=204, tags=["businesses"])
def remove_business_member(
    user_id: int,
    membership: models.BusinessMembership = Depends(require_roles("owner", "admin")),
    db: Session = Depends(get_db),
):
    target = db.scalar(select(models.BusinessMembership).where(
        models.BusinessMembership.business_id == membership.business_id,
        models.BusinessMembership.user_id == user_id,
    ))
    if target is None:
        raise HTTPException(status_code=404, detail="Business member not found")
    if target.role == "owner":
        raise HTTPException(status_code=409, detail="Owners cannot be removed through this endpoint")
    if membership.role == "admin" and target.role != "viewer" and target.role != "sales":
        raise HTTPException(status_code=403, detail="Admins can only remove sales and viewer members")
    db.delete(target)
    db.commit()
    return Response(status_code=204)


@app.post("/api/v1/businesses/invitations", response_model=schemas.InvitationCreated, status_code=201, tags=["businesses"])
def create_business_invitation(
    payload: schemas.InvitationCreate,
    membership: models.BusinessMembership = Depends(require_roles("owner", "admin")),
    db: Session = Depends(get_db),
):
    if payload.role == "admin" and membership.role != "owner":
        raise HTTPException(status_code=403, detail="Only the business owner can grant the admin role")
    email = payload.email.strip().lower()
    existing_member = db.scalar(
        select(models.BusinessMembership)
        .join(models.User)
        .where(models.BusinessMembership.business_id == membership.business_id, models.User.email == email)
    )
    if existing_member is not None:
        raise HTTPException(status_code=409, detail="This user is already a business member")
    now = datetime.now(timezone.utc)
    existing_invitation = db.scalar(select(models.BusinessInvitation).where(
        models.BusinessInvitation.business_id == membership.business_id,
        models.BusinessInvitation.email == email,
        models.BusinessInvitation.accepted_at.is_(None),
        models.BusinessInvitation.expires_at > now,
    ))
    if existing_invitation is not None:
        raise HTTPException(status_code=409, detail="A pending invitation already exists for this email")
    token = secrets.token_urlsafe(32)
    invitation = models.BusinessInvitation(
        business_id=membership.business_id,
        invited_by_user_id=membership.user_id,
        email=email,
        role=payload.role,
        token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(),
        expires_at=now + timedelta(days=7),
    )
    db.add(invitation)
    db.commit()
    db.refresh(invitation)
    try:
        email_sent = send_business_invitation(
            recipient=email,
            business_name=membership.business.name,
            role=payload.role,
            token=token,
            expires_at=invitation.expires_at.isoformat(),
        )
    except EmailDeliveryError as exc:
        logger.warning("Invitation email delivery failed for invitation %s: %s", invitation.id, exc)
        delivery_status = "failed"
        response_token = token
    else:
        delivery_status = "sent" if email_sent else "manual"
        response_token = None if email_sent else token
    return {
        "id": invitation.id,
        "business_id": invitation.business_id,
        "email": invitation.email,
        "role": invitation.role,
        "token": response_token,
        "invitation_url": f"{os.getenv('APP_BASE_URL', 'http://localhost:3000').rstrip('/')}/#token={token}" if response_token else None,
        "expires_at": invitation.expires_at,
        "delivery_status": delivery_status,
    }


@app.get("/api/v1/businesses/invitations", response_model=list[schemas.InvitationOut], tags=["businesses"])
def list_business_invitations(
    membership: models.BusinessMembership = Depends(require_roles("owner", "admin")),
    db: Session = Depends(get_db),
):
    return db.scalars(select(models.BusinessInvitation).where(
        models.BusinessInvitation.business_id == membership.business_id,
        models.BusinessInvitation.accepted_at.is_(None),
        models.BusinessInvitation.expires_at > datetime.now(timezone.utc),
    ).order_by(models.BusinessInvitation.created_at.desc())).all()


@app.delete("/api/v1/businesses/invitations/{invitation_id}", status_code=204, tags=["businesses"])
def revoke_business_invitation(
    invitation_id: int,
    membership: models.BusinessMembership = Depends(require_roles("owner", "admin")),
    db: Session = Depends(get_db),
):
    invitation = db.scalar(select(models.BusinessInvitation).where(
        models.BusinessInvitation.id == invitation_id,
        models.BusinessInvitation.business_id == membership.business_id,
        models.BusinessInvitation.accepted_at.is_(None),
    ))
    if invitation is None:
        raise HTTPException(status_code=404, detail="Pending invitation not found")
    if membership.role == "admin" and invitation.role == "admin":
        raise HTTPException(status_code=403, detail="Admins cannot revoke admin invitations")
    db.delete(invitation)
    db.commit()
    return Response(status_code=204)


@app.post("/api/v1/auth/invitations/accept", response_model=schemas.MembershipOut, tags=["authentication"])
def accept_business_invitation(
    payload: schemas.InvitationAccept,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    token_hash = hashlib.sha256(payload.token.encode("utf-8")).hexdigest()
    invitation = db.scalar(select(models.BusinessInvitation).where(
        models.BusinessInvitation.token_hash == token_hash,
    ).with_for_update())
    if invitation is None or invitation.accepted_at is not None:
        raise HTTPException(status_code=404, detail="Invitation is invalid or already used")
    if invitation.expires_at <= datetime.now(timezone.utc):
        raise HTTPException(status_code=410, detail="Invitation has expired")
    if invitation.email != current_user.email:
        raise HTTPException(status_code=403, detail="Sign in with the email address the invitation was sent to")
    if not current_user.email_verified:
        raise HTTPException(status_code=403, detail="Verify your email address before accepting this invitation")
    already_member = db.scalar(select(models.BusinessMembership).where(
        models.BusinessMembership.business_id == invitation.business_id,
        models.BusinessMembership.user_id == current_user.id,
    ))
    if already_member is not None:
        raise HTTPException(status_code=409, detail="You are already a member of this business")
    invitation.accepted_at = datetime.now(timezone.utc)
    membership = models.BusinessMembership(
        business_id=invitation.business_id,
        user_id=current_user.id,
        role=invitation.role,
    )
    db.add(membership)
    db.commit()
    business = db.get(models.Business, invitation.business_id)
    return {"business": business, "role": membership.role}


@app.post("/api/v1/customers", response_model=schemas.CustomerOut, status_code=201, tags=["customers"])
def create_customer(payload: schemas.CustomerCreate, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin", "sales")), db: Session = Depends(get_db)):
    customer = models.Customer(business_id=business.id, **payload.model_dump())
    db.add(customer)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A customer with this email already exists") from None
    db.refresh(customer)
    return customer


@app.get("/api/v1/customers", response_model=list[schemas.CustomerOut], tags=["customers"])
def list_customers(business: models.Business = Depends(require_business), db: Session = Depends(get_db)):
    return db.scalars(select(models.Customer).where(models.Customer.business_id == business.id).order_by(models.Customer.name)).all()


@app.patch("/api/v1/customers/{customer_id:int}", response_model=schemas.CustomerOut, tags=["customers"])
def update_customer(customer_id: int, payload: schemas.CustomerUpdate, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    values = payload.model_dump(exclude_unset=True)
    if not values:
        raise HTTPException(status_code=400, detail="Provide at least one customer field to update")
    customer = db.scalar(select(models.Customer).where(models.Customer.id == customer_id, models.Customer.business_id == business.id))
    if customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")
    for key, value in values.items():
        setattr(customer, key, value)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A customer with this email already exists") from None
    db.refresh(customer)
    return customer


@app.delete("/api/v1/customers/{customer_id:int}", status_code=204, tags=["customers"])
def delete_customer(customer_id: int, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    customer = db.scalar(select(models.Customer).where(models.Customer.id == customer_id, models.Customer.business_id == business.id))
    if customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")
    db.delete(customer)
    db.commit()
    return Response(status_code=204)


@app.get("/api/v1/customers/{customer_id:int}/stats", response_model=schemas.CustomerStatsOut, tags=["customers"])
def customer_stats(
    customer_id: int,
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    customer = db.scalar(select(models.Customer).where(models.Customer.id == customer_id, models.Customer.business_id == business.id))
    if customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")
    orders_count, total_spend = db.execute(
        select(func.count(models.Sale.id), func.coalesce(func.sum(models.Sale.total_minor), 0))
        .where(models.Sale.customer_id == customer.id, models.Sale.business_id == business.id)
    ).one()
    last_sale = db.scalar(
        select(models.Sale.created_at)
        .where(models.Sale.customer_id == customer.id, models.Sale.business_id == business.id)
        .order_by(models.Sale.created_at.desc())
        .limit(1)
    )
    return {
        "customer": customer,
        "total_spend_minor": total_spend,
        "order_count": orders_count,
        "average_order_minor": round(total_spend / orders_count) if orders_count else 0,
        "first_order_date": db.scalar(
            select(func.min(models.Sale.created_at)).where(models.Sale.customer_id == customer.id, models.Sale.business_id == business.id)
        ),
        "latest_order_date": last_sale,
        "recent_sales": db.scalars(
            select(models.Sale)
            .options(selectinload(models.Sale.items))
            .where(models.Sale.customer_id == customer.id, models.Sale.business_id == business.id)
            .order_by(models.Sale.created_at.desc())
            .limit(50)
        ).all(),
    }


@app.post("/api/v1/customers/import", tags=["customers"])
def import_customers(payload: schemas.CustomerImportRequest, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin", "sales")), db: Session = Depends(get_db)):
    seen: set[str] = set()
    conflicts: list[dict[str, object]] = []
    existing = {
        email.casefold()
        for email in db.scalars(select(models.Customer.email).where(
            models.Customer.business_id == business.id,
            models.Customer.email.is_not(None),
        )).all()
        if email
    }
    for row_number, row in enumerate(payload.rows, start=2):
        email = row.email.casefold() if row.email else None
        if email and (email in seen or email in existing):
            conflicts.append({"row": row_number, "field": "email", "message": "Email already exists in this file or workspace"})
        if email:
            seen.add(email)
    if conflicts:
        raise HTTPException(status_code=409, detail={"message": "No customers were imported. Fix the duplicate emails and try again.", "rows": conflicts})
    db.add_all([models.Customer(business_id=business.id, **row.model_dump()) for row in payload.rows])
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="No customers were imported because a duplicate email was added at the same time. Refresh and try again.") from None
    return {"created": len(payload.rows)}


@app.post("/api/v1/products", response_model=schemas.ProductOut, status_code=201, tags=["products"])
def create_product(payload: schemas.ProductCreate, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    product = models.Product(business_id=business.id, **payload.model_dump())
    db.add(product)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A product with this SKU already exists") from None
    db.refresh(product)
    return product


@app.get("/api/v1/products", response_model=list[schemas.ProductOut], tags=["products"])
def list_products(business: models.Business = Depends(require_business), db: Session = Depends(get_db)):
    return db.scalars(select(models.Product).where(models.Product.business_id == business.id).order_by(models.Product.name)).all()


@app.patch("/api/v1/products/{product_id:int}", response_model=schemas.ProductOut, tags=["products"])
def update_product(product_id: int, payload: schemas.ProductUpdate, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    values = payload.model_dump(exclude_unset=True)
    if not values:
        raise HTTPException(status_code=400, detail="Provide at least one product field to update")
    product = db.scalar(select(models.Product).where(models.Product.id == product_id, models.Product.business_id == business.id))
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    for key, value in values.items():
        setattr(product, key, value)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A product with this SKU already exists") from None
    db.refresh(product)
    return product


@app.delete("/api/v1/products/{product_id:int}", tags=["products"])
def delete_product(product_id: int, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    product = db.scalar(select(models.Product).where(models.Product.id == product_id, models.Product.business_id == business.id))
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    has_sales = db.scalar(select(models.SaleItem.id).where(models.SaleItem.product_id == product.id).limit(1)) is not None
    if has_sales:
        product.active = False
        db.commit()
        return {"deleted": False, "deactivated": True}
    db.delete(product)
    db.commit()
    return {"deleted": True, "deactivated": False}


@app.post("/api/v1/products/import", tags=["products"])
def import_products(payload: schemas.ProductImportRequest, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    seen: set[str] = set()
    conflicts: list[dict[str, object]] = []
    existing = {
        sku.casefold()
        for sku in db.scalars(select(models.Product.sku).where(models.Product.business_id == business.id)).all()
    }
    for row_number, row in enumerate(payload.rows, start=2):
        sku = row.sku.casefold()
        if sku in seen or sku in existing:
            conflicts.append({"row": row_number, "field": "sku", "message": "SKU already exists in this file or workspace"})
        seen.add(sku)
    if conflicts:
        raise HTTPException(status_code=409, detail={"message": "No products were imported. Fix the duplicate SKUs and try again.", "rows": conflicts})
    db.add_all([models.Product(business_id=business.id, **row.model_dump()) for row in payload.rows])
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="No products were imported because a duplicate SKU was added at the same time. Refresh and try again.") from None
    return {"created": len(payload.rows)}


@app.post("/api/v1/sales", response_model=schemas.SaleOut, status_code=201, tags=["sales"])
def create_sale(payload: schemas.SaleCreate, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin", "sales")), db: Session = Depends(get_db)):
    quantities: dict[int, int] = {}
    for item in payload.items:
        quantities[item.product_id] = quantities.get(item.product_id, 0) + item.quantity

    if payload.customer_id is not None:
        customer = db.scalar(select(models.Customer).where(
            models.Customer.id == payload.customer_id,
            models.Customer.business_id == business.id,
        ))
        if customer is None:
            raise HTTPException(status_code=404, detail="Customer not found in this business")

    products = db.scalars(
        select(models.Product)
        .where(models.Product.id.in_(quantities), models.Product.business_id == business.id)
        .order_by(models.Product.id)
        .with_for_update()
    ).all()
    product_by_id = {product.id: product for product in products}
    if len(product_by_id) != len(quantities):
        raise HTTPException(status_code=404, detail="One or more products were not found in this business")
    for product_id, quantity in quantities.items():
        product = product_by_id[product_id]
        if not product.active:
            raise HTTPException(status_code=409, detail=f"Product {product.name} is inactive")
        if product.stock_quantity < quantity:
            raise HTTPException(status_code=409, detail=f"Insufficient stock for {product.name}")

    sale = models.Sale(business_id=business.id, customer_id=payload.customer_id, total_minor=0, currency=business.currency)
    for product_id, quantity in quantities.items():
        product = product_by_id[product_id]
        product.stock_quantity -= quantity
        sale.items.append(models.SaleItem(
            product_id=product.id,
            product_name=product.name,
            quantity=quantity,
            unit_price_minor=product.price_minor,
            unit_cost_minor=product.cost_price_minor,
        ))
        sale.total_minor += product.price_minor * quantity
    db.add(sale)
    db.commit()
    db.refresh(sale)
    return sale


@app.post("/api/v1/sales/import", tags=["sales"])
def import_sales(payload: schemas.SaleImportRequest, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin", "sales")), db: Session = Depends(get_db)):
    products = db.scalars(select(models.Product).where(models.Product.business_id == business.id)).all()
    products_by_sku = {product.sku.casefold(): product for product in products}
    customers = db.scalars(select(models.Customer).where(models.Customer.business_id == business.id)).all()
    customers_by_name: dict[str, list[models.Customer]] = {}
    for customer in customers:
        customers_by_name.setdefault(customer.name.casefold(), []).append(customer)
    submitted_refs = {row.sale_ref.casefold() for row in payload.rows}
    existing_sales = db.scalars(
        select(models.Sale)
        .options(selectinload(models.Sale.items))
        .where(
            models.Sale.business_id == business.id,
            func.lower(models.Sale.external_reference).in_(submitted_refs),
        )
    ).all()
    existing_by_ref = {
        sale.external_reference.casefold(): sale
        for sale in existing_sales
        if sale.external_reference
    }

    groups: dict[str, dict[str, object]] = {}
    conflicts: list[dict[str, object]] = []
    for row_number, row in enumerate(payload.rows, start=2):
        reference = row.sale_ref.casefold()
        sold_at = row.sold_at.astimezone(timezone.utc)
        customer_name = row.customer_name.casefold() if row.customer_name else None
        group = groups.get(reference)
        if group is None:
            group = {"reference": row.sale_ref, "sold_at": sold_at, "customer_name": customer_name, "items": [], "total": 0, "first_row": row_number}
            groups[reference] = group
        elif group["sold_at"] != sold_at or group["customer_name"] != customer_name:
            conflicts.append({"row": row_number, "message": "Rows with the same sale_ref must have the same sold_at and customer_name"})
            continue

        product = products_by_sku.get(row.sku.casefold())
        if product is None:
            conflicts.append({"row": row_number, "message": f"SKU {row.sku} was not found in this workspace"})
            continue
        matching_customers = customers_by_name.get(customer_name, []) if customer_name else []
        if customer_name and not matching_customers:
            conflicts.append({"row": row_number, "message": f"Customer {row.customer_name} was not found in this workspace"})
            continue
        if len(matching_customers) > 1:
            conflicts.append({"row": row_number, "message": f"More than one customer is named {row.customer_name}; use a unique customer name"})
            continue
        customer = matching_customers[0] if matching_customers else None
        new_total = int(group["total"]) + row.quantity * row.unit_price_minor
        if new_total > 2_147_483_647:
            conflicts.append({"row": row_number, "message": "Sale total exceeds the supported maximum"})
            continue
        group["total"] = new_total
        group["items"].append((product, row.quantity, row.unit_price_minor, row.unit_cost_minor))
        group["customer"] = customer

    sales: list[models.Sale] = []
    cost_backfills: list[tuple[models.SaleItem, int]] = []
    for reference, group in groups.items():
        existing_sale = existing_by_ref.get(reference)
        if existing_sale is not None:
            row_number = int(group["first_row"])
            incoming_items = group["items"]
            if not any(unit_cost_minor is not None for _, _, _, unit_cost_minor in incoming_items):
                conflicts.append({"row": row_number, "message": f"Sale reference {group['reference']} already exists. Include unit_cost to add missing historical costs."})
                continue

            existing_created_at = existing_sale.created_at
            if existing_created_at.tzinfo is None:
                existing_created_at = existing_created_at.replace(tzinfo=timezone.utc)
            else:
                existing_created_at = existing_created_at.astimezone(timezone.utc)
            customer = group.get("customer")
            incoming_counts = Counter((product.id, quantity, unit_price_minor) for product, quantity, unit_price_minor, _ in incoming_items)
            existing_counts = Counter((item.product_id, item.quantity, item.unit_price_minor) for item in existing_sale.items)
            if (
                existing_created_at != group["sold_at"]
                or (customer is not None and existing_sale.customer_id != customer.id)
                or existing_sale.total_minor != group["total"]
                or incoming_counts != existing_counts
            ):
                conflicts.append({"row": row_number, "message": f"Sale reference {group['reference']} exists, but its date, customer, or line items do not match. No changes were made."})
                continue

            line_items_by_key: dict[tuple[int | None, int, int], list[models.SaleItem]] = defaultdict(list)
            for item in existing_sale.items:
                line_items_by_key[(item.product_id, item.quantity, item.unit_price_minor)].append(item)
            for product, quantity, unit_price_minor, unit_cost_minor in incoming_items:
                item = line_items_by_key[(product.id, quantity, unit_price_minor)].pop(0)
                if unit_cost_minor is None:
                    continue
                if item.unit_cost_minor is None:
                    cost_backfills.append((item, unit_cost_minor))
                elif item.unit_cost_minor != unit_cost_minor:
                    conflicts.append({"row": row_number, "message": f"Sale reference {group['reference']} already has a different cost for {product.sku}. Existing costs were preserved."})
                    break
            continue

        sale = models.Sale(
            business_id=business.id,
            customer_id=group["customer"].id if group.get("customer") else None,
            total_minor=group["total"],
            currency=business.currency,
            external_reference=group["reference"],
            created_at=group["sold_at"],
        )
        for product, quantity, unit_price_minor, unit_cost_minor in group["items"]:
            sale.items.append(models.SaleItem(
                product_id=product.id,
                product_name=product.name,
                quantity=quantity,
                unit_price_minor=unit_price_minor,
                unit_cost_minor=unit_cost_minor,
            ))
        sales.append(sale)

    if conflicts:
        raise HTTPException(status_code=409, detail={"message": "No sales were imported or updated. Fix the flagged rows and try again.", "rows": conflicts})

    for item, unit_cost_minor in cost_backfills:
        item.unit_cost_minor = unit_cost_minor
    db.add_all(sales)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="No sales were imported because a sale reference was already added. Refresh and try again.") from None
    return {"created": len(sales), "cost_lines_updated": len(cost_backfills), "rows": len(payload.rows)}


@app.get("/api/v1/sales", response_model=list[schemas.SaleOut], tags=["sales"])
def list_sales(
    from_date: date | None = None,
    to_date: date | None = None,
    customer_id: int | None = Query(default=None, gt=0),
    product_id: int | None = Query(default=None, gt=0),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    start_utc, end_utc, _, _, _ = reporting_window(business, from_date, to_date)
    statement = (
        select(models.Sale)
        .options(selectinload(models.Sale.items))
        .where(
            models.Sale.business_id == business.id,
            models.Sale.created_at >= start_utc,
            models.Sale.created_at < end_utc,
        )
        .order_by(models.Sale.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    if customer_id is not None:
        statement = statement.where(models.Sale.customer_id == customer_id)
    if product_id is not None:
        statement = statement.where(select(models.SaleItem.id).where(models.SaleItem.sale_id == models.Sale.id, models.SaleItem.product_id == product_id).exists())
    return db.scalars(statement).all()


@app.patch("/api/v1/sales/{sale_id:int}", response_model=schemas.SaleOut, tags=["sales"])
def update_sale(sale_id: int, payload: schemas.SaleCorrection, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    sale = db.scalar(
        select(models.Sale)
        .options(selectinload(models.Sale.items))
        .where(models.Sale.id == sale_id, models.Sale.business_id == business.id)
        .with_for_update()
    )
    if sale is None:
        raise HTTPException(status_code=404, detail="Sale not found")
    if payload.customer_id is not None:
        customer = db.scalar(select(models.Customer).where(
            models.Customer.id == payload.customer_id,
            models.Customer.business_id == business.id,
        ))
        if customer is None:
            raise HTTPException(status_code=404, detail="Customer not found in this business")

    previous_quantities: dict[int, int] = {}
    for item in sale.items:
        if item.product_id is not None:
            previous_quantities[item.product_id] = previous_quantities.get(item.product_id, 0) + item.quantity
    new_quantities: dict[int, int] = {}
    for item in payload.items:
        new_quantities[item.product_id] = new_quantities.get(item.product_id, 0) + item.quantity
    product_ids = set(previous_quantities) | set(new_quantities)
    linked_products = db.scalars(
        select(models.Product)
        .where(models.Product.business_id == business.id, models.Product.id.in_(product_ids))
        .order_by(models.Product.id)
        .with_for_update()
    ).all() if product_ids else []
    products_by_id = {product.id: product for product in linked_products}
    if set(new_quantities) - products_by_id.keys():
        raise HTTPException(status_code=404, detail="One or more products were not found in this business")

    total_minor = sum(item.quantity * item.unit_price_minor for item in payload.items)
    if total_minor > 2_147_483_647:
        raise HTTPException(status_code=422, detail="Sale total exceeds the supported maximum")
    is_historical_import = sale.external_reference is not None
    if not is_historical_import:
        for product_id in set(new_quantities) - previous_quantities.keys():
            if not products_by_id[product_id].active:
                raise HTTPException(status_code=409, detail=f"Product {products_by_id[product_id].name} is inactive")
        for product_id, product in products_by_id.items():
            available = product.stock_quantity + previous_quantities.get(product_id, 0)
            requested = new_quantities.get(product_id, 0)
            if requested > available:
                raise HTTPException(status_code=409, detail=f"Insufficient stock for {product.name}")
            product.stock_quantity = available - requested

    sale.customer_id = payload.customer_id
    sale.total_minor = total_minor
    sale.items.clear()
    for item in payload.items:
        product = products_by_id[item.product_id]
        sale.items.append(models.SaleItem(
            product_id=product.id,
            product_name=product.name,
            quantity=item.quantity,
            unit_price_minor=item.unit_price_minor,
            unit_cost_minor=product.cost_price_minor,
        ))
    db.commit()
    db.refresh(sale)
    return sale


@app.delete("/api/v1/sales/{sale_id:int}", status_code=204, tags=["sales"])
def delete_sale(sale_id: int, business: models.Business = Depends(require_business), _role: models.BusinessMembership = Depends(require_roles("owner", "admin")), db: Session = Depends(get_db)):
    sale = db.scalar(
        select(models.Sale)
        .options(selectinload(models.Sale.items))
        .where(models.Sale.id == sale_id, models.Sale.business_id == business.id)
        .with_for_update()
    )
    if sale is None:
        raise HTTPException(status_code=404, detail="Sale not found")
    if sale.external_reference is None:
        product_ids = {item.product_id for item in sale.items if item.product_id is not None}
        if product_ids:
            linked_products = db.scalars(
                select(models.Product)
                .where(models.Product.business_id == business.id, models.Product.id.in_(product_ids))
                .with_for_update()
            ).all()
            products_by_id = {product.id: product for product in linked_products}
            for item in sale.items:
                product = products_by_id.get(item.product_id)
                if product is not None:
                    product.stock_quantity += item.quantity
    db.delete(sale)
    db.commit()
    return Response(status_code=204)


@app.get("/api/v1/dashboard/summary", tags=["analytics"])
def dashboard_summary(
    from_date: date | None = None,
    to_date: date | None = None,
    customer_id: int | None = Query(default=None, gt=0),
    product_id: int | None = Query(default=None, gt=0),
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    start_utc, end_utc, start_day, end_day, _ = reporting_window(business, from_date, to_date)
    conditions = [models.Sale.business_id == business.id, models.Sale.created_at >= start_utc, models.Sale.created_at < end_utc]
    if customer_id is not None:
        conditions.append(models.Sale.customer_id == customer_id)
    if product_id is not None:
        count, revenue = db.execute(
            select(func.count(models.Sale.id.distinct()), func.coalesce(func.sum(models.SaleItem.quantity * models.SaleItem.unit_price_minor), 0))
            .join(models.SaleItem, models.SaleItem.sale_id == models.Sale.id).where(*conditions, models.SaleItem.product_id == product_id)
        ).one()
    else:
        count, revenue = db.execute(
            select(func.count(models.Sale.id), func.coalesce(func.sum(models.Sale.total_minor), 0))
            .where(*conditions)
        ).one()
    cost = db.execute(
        select(
            func.count(models.SaleItem.id),
            func.count(models.SaleItem.unit_cost_minor),
            func.coalesce(func.sum(models.SaleItem.quantity * models.SaleItem.unit_cost_minor), 0),
        )
        .join(models.Sale, models.Sale.id == models.SaleItem.sale_id)
        .where(*conditions)
        .where(*([models.SaleItem.product_id == product_id] if product_id is not None else []))
    ).one()
    item_count, known_cost_count, cost_minor = cost
    cost_complete = item_count == known_cost_count
    gross_profit = revenue - cost_minor if cost_complete else None
    profit_margin = round((gross_profit / revenue) * 100, 1) if revenue and gross_profit is not None else None
    return {
        "business_id": business.id,
        "currency": business.currency,
        "from_date": start_day,
        "to_date": end_day,
        "order_count": count,
        "revenue_minor": revenue,
        "cost_minor": cost_minor if cost_complete else None,
        "gross_profit_minor": gross_profit,
        "profit_margin_pct": profit_margin,
        "profit_data_complete": cost_complete,
        "average_order_value_minor": round(revenue / count) if count else 0,
    }


@app.get("/api/v1/analytics/sales-trend", tags=["analytics"])
def sales_trend(
    from_date: date | None = None,
    to_date: date | None = None,
    interval: Literal["day", "week", "month"] = "day",
    customer_id: int | None = Query(default=None, gt=0),
    product_id: int | None = Query(default=None, gt=0),
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    start_utc, end_utc, start_day, end_day, _ = reporting_window(business, from_date, to_date)
    local_created_at = func.timezone(business.timezone, models.Sale.created_at)
    bucket_expr = func.date_trunc(interval, local_created_at)
    conditions = [models.Sale.business_id == business.id, models.Sale.created_at >= start_utc, models.Sale.created_at < end_utc]
    if customer_id is not None:
        conditions.append(models.Sale.customer_id == customer_id)
    trend_query = select(
            bucket_expr.label("bucket"),
            func.count(models.Sale.id.distinct()).label("order_count"),
            func.coalesce(func.sum(models.Sale.total_minor), 0).label("revenue_minor"),
        ).where(*conditions)
    if product_id is not None:
        trend_query = select(bucket_expr.label("bucket"), func.count(models.Sale.id.distinct()).label("order_count"), func.coalesce(func.sum(models.SaleItem.quantity * models.SaleItem.unit_price_minor), 0).label("revenue_minor")).join(models.SaleItem, models.SaleItem.sale_id == models.Sale.id).where(*conditions, models.SaleItem.product_id == product_id)
    rows = db.execute(
        trend_query.group_by(bucket_expr).order_by(bucket_expr)
    ).all()
    values = {row.bucket.date(): (row.order_count, row.revenue_minor) for row in rows}
    buckets = []
    for bucket_day in report_buckets(interval, start_day, end_day):
        count, revenue = values.get(bucket_day, (0, 0))
        buckets.append({
            "bucket_start": bucket_day,
            "order_count": count,
            "revenue_minor": revenue,
            "average_order_value_minor": round(revenue / count) if count else 0,
        })
    return {
        "business_id": business.id,
        "currency": business.currency,
        "interval": interval,
        "from_date": start_day,
        "to_date": end_day,
        "buckets": buckets,
    }


@app.get("/api/v1/analytics/top-products", tags=["analytics"])
def top_products(
    from_date: date | None = None,
    to_date: date | None = None,
    limit: int = Query(default=10, ge=1, le=100),
    customer_id: int | None = Query(default=None, gt=0),
    product_id: int | None = Query(default=None, gt=0),
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    start_utc, end_utc, start_day, end_day, _ = reporting_window(business, from_date, to_date)
    rows = db.execute(
        select(
            models.SaleItem.product_name,
            func.sum(models.SaleItem.quantity).label("units_sold"),
            func.sum(models.SaleItem.quantity * models.SaleItem.unit_price_minor).label("revenue_minor"),
        )
        .join(models.Sale, models.Sale.id == models.SaleItem.sale_id)
        .where(
            models.Sale.business_id == business.id,
            models.Sale.created_at >= start_utc,
            models.Sale.created_at < end_utc,
            *([models.Sale.customer_id == customer_id] if customer_id is not None else []),
            *([models.SaleItem.product_id == product_id] if product_id is not None else []),
        )
        .group_by(models.SaleItem.product_name)
        .order_by(
            func.sum(models.SaleItem.quantity * models.SaleItem.unit_price_minor).desc(),
            func.sum(models.SaleItem.quantity).desc(),
            models.SaleItem.product_name,
        )
        .limit(limit)
    ).all()
    return {
        "business_id": business.id,
        "currency": business.currency,
        "from_date": start_day,
        "to_date": end_day,
        "products": [
            {"product_name": row.product_name, "units_sold": row.units_sold, "revenue_minor": row.revenue_minor}
            for row in rows
        ],
    }


@app.get("/api/v1/reports/sales.csv", tags=["reports"])
def export_sales_csv(
    from_date: date | None = None,
    to_date: date | None = None,
    customer_id: int | None = Query(default=None, gt=0),
    product_id: int | None = Query(default=None, gt=0),
    business: models.Business = Depends(require_business),
    db: Session = Depends(get_db),
):
    start_utc, end_utc, start_day, end_day, business_zone = reporting_window(business, from_date, to_date)
    sales_statement = select(models.Sale)
    if product_id is not None:
        sales_statement = sales_statement.where(select(models.SaleItem.id).where(models.SaleItem.sale_id == models.Sale.id, models.SaleItem.product_id == product_id).exists())
    if customer_id is not None:
        sales_statement = sales_statement.where(models.Sale.customer_id == customer_id)
    sales = db.scalars(
        sales_statement
        .options(selectinload(models.Sale.items))
        .where(
            models.Sale.business_id == business.id,
            models.Sale.created_at >= start_utc,
            models.Sale.created_at < end_utc,
        )
        .order_by(models.Sale.created_at)
        .limit(50001)
    ).all()
    if len(sales) > 50000:
        raise HTTPException(status_code=413, detail="Export exceeds 50,000 sales; narrow the date range")
    output = StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow([
        "sale_id", "sold_at_local", "customer_id", "total_minor", "currency",
        "product_id", "product_name", "quantity", "unit_price_minor", "line_total_minor",
    ])
    for sale in sales:
        sold_at = sale.created_at.astimezone(business_zone).isoformat()
        for item in sale.items:
            if product_id is not None and item.product_id != product_id:
                continue
            writer.writerow([
                sale.id,
                sold_at,
                sale.customer_id or "",
                sale.total_minor,
                csv_safe(sale.currency),
                item.product_id or "",
                csv_safe(item.product_name),
                item.quantity,
                item.unit_price_minor,
                item.quantity * item.unit_price_minor,
            ])
    filename = f"sales-{start_day.isoformat()}-to-{end_day.isoformat()}.csv"
    return Response(
        content=output.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
